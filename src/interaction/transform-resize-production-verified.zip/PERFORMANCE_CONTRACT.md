# Production Resize Performance Contract

## Frame architecture

- Pointer/Moveable events only compute the newest absolute transform patch.
- `TransformSystem` owns the single `requestAnimationFrame` gate.
- Repeated events before paint replace `pendingTransforms`; they do not publish extra store updates.
- One atomic preview map is published to the transform store and preview listeners.
- Renderer, overlay, guides, inspector, and dimension labels must select the active node from this same preview map.
- The scene graph is not mutated until `commitTransform()`.

## React integration requirement

To preserve the 500–1000 node guarantee, scene-node components must not subscribe to the entire preview map. Each node should select only its own preview transform and use an equality comparator. Non-selected nodes then receive the same selected value and do not re-render.

Example host-store selector pattern:

```ts
const preview = useTransformStore(
  (state) => state.previewTransforms[nodeId],
  shallowTransformEqual,
);
```

Do not use:

```ts
const previewTransforms = useTransformStore((state) => state.previewTransforms);
```

The second form invalidates every subscriber on every active frame.

## DOM/layout rules

- No `getBoundingClientRect`, `offsetWidth`, `offsetHeight`, computed style, or DOM query is performed by the resize event handler.
- Moveable `useAccuratePosition` is intentionally disabled because that option uses bounding-client-rect positioning.
- Width/height badge updates are direct writes driven by the same published preview frame, not a separate pointer-event clock.
- No scene-node DOM mutation is performed by the adapter; rendering remains owned by the renderer.

## Commit rules

- Preview updates are ephemeral and active-node-only.
- History/command/scene graph receive one final transform at gesture end.
- Cancel discards pending and published preview state without scene mutation.
