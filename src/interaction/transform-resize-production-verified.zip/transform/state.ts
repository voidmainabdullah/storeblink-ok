import { createFieldUpdateCommand, createTransformCommand, dispatch, type CommandContext, type TransformKind } from "@/engine/command";
import type { SceneGraphAPI } from "@/engine/scene-graph";
import { getTransformedOBB, polygonToAABB } from "@/rendering/geometry";
import { getWorldTransform } from "@/rendering/coordinate";
import { sceneStoreCommandGraph, sceneStoreGraph } from "@/stores/sceneGraphAdapter";
import { useTransformStore } from "@/stores/transform.store";
import type { NodeId, Point, Rect, SceneNode, TransformData } from "@/types";
import { computeSnap } from "@/interaction/snap";
import { interactionElevationSystem } from "@/interaction/elevation";
import { responsiveSystem } from "@/layout/responsive";

export type TransformMapDelta = {
  nodes: Record<NodeId, Partial<TransformData>>;
};

export type TransformDelta = Partial<TransformData> | Point | TransformMapDelta;

export type PreviewTransformListener = (transforms: Readonly<Record<NodeId, TransformData>>) => void;

export type TransformAPI = {
  beginTransform(ids: NodeId[], kind: TransformKind): void;
  updateTransform(delta: TransformDelta): void;
  commitTransform(): void;
  cancelTransform(): void;
  flushPreview(): void;
  getInitialTransform(nodeId: NodeId): TransformData | undefined;
  subscribePreview(listener: PreviewTransformListener): () => void;
};

export type TransformSystemOptions = {
  sceneGraph?: SceneGraphAPI;
  commandContext?: CommandContext;
  gridSize?: number;
  snapThreshold?: number;
};

const cloneTransform = (transform: TransformData): TransformData => ({
  ...transform,
  transformOrigin: [...transform.transformOrigin],
});

const isPointDelta = (delta: TransformDelta): delta is Point =>
  "x" in delta && "y" in delta && !("width" in delta) && !("height" in delta) && !("rotation" in delta);

const isTransformMapDelta = (delta: TransformDelta): delta is TransformMapDelta => "nodes" in delta;

const finiteOr = (value: number, fallback: number): number => (Number.isFinite(value) ? value : fallback);

const clampTransform = (transform: TransformData): TransformData => ({
  ...transform,
  x: finiteOr(transform.x, 0),
  y: finiteOr(transform.y, 0),
  width: Math.max(1, finiteOr(transform.width, 1)),
  height: Math.max(1, finiteOr(transform.height, 1)),
  rotation: finiteOr(transform.rotation, 0),
  scaleX: finiteOr(transform.scaleX, 1),
  scaleY: finiteOr(transform.scaleY, 1),
  skewX: finiteOr(transform.skewX, 0),
  skewY: finiteOr(transform.skewY, 0),
  zIndex: finiteOr(transform.zIndex, 0),
});

const cloneProps = (props: Record<string, unknown>) => ({ ...props });

const transformsEqual = (a: TransformData | undefined, b: TransformData | undefined): boolean =>
  Boolean(
    a &&
      b &&
      a.x === b.x &&
      a.y === b.y &&
      a.width === b.width &&
      a.height === b.height &&
      a.rotation === b.rotation &&
      a.scaleX === b.scaleX &&
      a.scaleY === b.scaleY &&
      a.skewX === b.skewX &&
      a.skewY === b.skewY &&
      a.zIndex === b.zIndex &&
      a.transformOrigin[0] === b.transformOrigin[0] &&
      a.transformOrigin[1] === b.transformOrigin[1],
  );

const scaledTextProps = (
  node: SceneNode | undefined,
  before: TransformData | undefined,
  after: TransformData | undefined,
  gestureKind: TransformKind | null,
) => {
  if (!node || node.type !== "text" || gestureKind !== "resize" || !before || !after || before.height <= 0) return null;
  const currentFontSize = Number(node.props.fontSize ?? 16);
  if (!Number.isFinite(currentFontSize) || currentFontSize <= 0) return null;
  const ratio = after.height / before.height;
  if (!Number.isFinite(ratio) || Math.abs(ratio - 1) < 0.01) return null;
  const nextFontSize = Math.max(4, Math.min(300, Math.round(currentFontSize * ratio * 100) / 100));
  return {
    before: cloneProps(node.props),
    after: { ...node.props, fontSize: nextFontSize },
  };
};

export class TransformSystem implements TransformAPI {
  private sceneGraph: SceneGraphAPI;
  private commandContext: CommandContext;
  private initialTransforms: Record<NodeId, TransformData> = {};
  private pendingTransforms: Record<NodeId, TransformData> | null = null;
  private frameId: number | null = null;
  private lastPublishedTransforms: Record<NodeId, TransformData> | null = null;
  private previewListeners = new Set<PreviewTransformListener>();
  private gridSize: number;
  private snapThreshold: number;

  constructor(options: TransformSystemOptions = {}) {
    this.sceneGraph = options.sceneGraph ?? sceneStoreGraph;
    this.commandContext = options.commandContext ?? { sceneGraph: sceneStoreCommandGraph };
    this.gridSize = options.gridSize ?? 8;
    this.snapThreshold = options.snapThreshold ?? 4;
  }

  configure(options: TransformSystemOptions = {}): void {
    this.sceneGraph = options.sceneGraph ?? this.sceneGraph;
    this.commandContext = options.commandContext ?? this.commandContext;
    this.gridSize = options.gridSize ?? this.gridSize;
    this.snapThreshold = options.snapThreshold ?? this.snapThreshold;
  }

  beginTransform(ids: NodeId[], kind: TransformKind): void {
    const sourceNodes = ids
      .map((id) => this.sceneGraph.getNode(id))
      .filter((node): node is SceneNode => Boolean(node && !node.meta.locked && !node.meta.hidden));
    const nodes = sourceNodes.map((node) =>
      responsiveSystem.hasOverrides(node) ? responsiveSystem.resolveNode(node) : node,
    );
    this.initialTransforms = Object.fromEntries(nodes.map((node) => [node.id, cloneTransform(node.transform)]));
    this.pendingTransforms = null;
    this.lastPublishedTransforms = null;
    interactionElevationSystem.begin(nodes.map((node) => node.id), this.sceneGraph);
    useTransformStore
      .getState()
      .beginTransformFromTransformSystem(nodes.map((node) => node.id), kind, this.initialTransforms);
  }

  getInitialTransform(nodeId: NodeId): TransformData | undefined {
    const transform = this.initialTransforms[nodeId];
    return transform ? cloneTransform(transform) : undefined;
  }

  subscribePreview(listener: PreviewTransformListener): () => void {
    this.previewListeners.add(listener);
    return () => this.previewListeners.delete(listener);
  }

  updateTransform(delta: TransformDelta): void {
    const { activeNodeIds } = useTransformStore.getState();
    if (!activeNodeIds.length) return;
    const nextTransforms: Record<NodeId, TransformData> = {};
    const snapDelta = this.getSnapDelta(activeNodeIds, delta);

    activeNodeIds.forEach((nodeId) => {
      const initial = this.initialTransforms[nodeId];
      if (!initial) return;
      if (isTransformMapDelta(delta)) {
        nextTransforms[nodeId] = clampTransform({ ...initial, ...(delta.nodes[nodeId] ?? {}) });
        return;
      }
      if (isPointDelta(delta)) {
        nextTransforms[nodeId] = clampTransform({
          ...initial,
          x: initial.x + delta.x + snapDelta.x,
          y: initial.y + delta.y + snapDelta.y,
        });
        return;
      }

      nextTransforms[nodeId] = clampTransform({ ...initial, ...delta });
    });

    this.pendingTransforms = nextTransforms;
    this.schedulePreviewFlush();
  }

  commitTransform(): void {
    this.flushPreview();
    const { activeNodeIds, gestureKind, previewTransforms } = useTransformStore.getState().getTransformSnapshot();
    if (!gestureKind || !activeNodeIds.length) return;
    const changes = activeNodeIds
      .map((nodeId) => {
        const before = this.initialTransforms[nodeId];
        const after = previewTransforms[nodeId];
        const sourceNode = this.sceneGraph.getNode(nodeId);
        const interactionNode =
          sourceNode && responsiveSystem.hasOverrides(sourceNode)
            ? responsiveSystem.resolveNode(sourceNode)
            : sourceNode;
        const textProps = scaledTextProps(interactionNode, before, after, gestureKind);
        return {
          nodeId,
          before,
          after,
          ...(textProps ? { propsBefore: textProps.before, propsAfter: textProps.after } : {}),
        };
      })
      .filter((change) => change.before && change.after)
      .filter((change) => !transformsEqual(change.before, change.after) || Boolean(change.propsBefore || change.propsAfter))
      .map((change) => ({
        nodeId: change.nodeId,
        before: change.before,
        after: change.after,
        ...(change.propsBefore ? { propsBefore: change.propsBefore } : {}),
        ...(change.propsAfter ? { propsAfter: change.propsAfter } : {}),
      }));

    if (changes.length) {
      const responsiveChanges = changes
        .map((change) => {
          const node = this.sceneGraph.getNode(change.nodeId);
          if (!node || !responsiveSystem.hasOverrides(node)) return null;
          return {
            nodeId: node.id,
            before: node.layout,
            after: responsiveSystem.updateLayout(node, responsiveSystem.getActiveBreakpoint(), {
              transform: change.after,
              ...(change.propsAfter ? { props: change.propsAfter } : {}),
            }),
          };
        })
        .filter((change): change is { nodeId: NodeId; before: SceneNode["layout"]; after: SceneNode["layout"] } => Boolean(change));
      if (responsiveChanges.length === changes.length) {
        dispatch(createFieldUpdateCommand("layout", responsiveChanges), this.commandContext);
      } else {
        dispatch(createTransformCommand(gestureKind, changes), this.commandContext);
      }
    }
    this.clear();
  }

  cancelTransform(): void {
    this.clear();
  }

  flushPreview(): void {
    const next = this.pendingTransforms;
    if (!next) return;
    this.pendingTransforms = null;

    if (this.previewMapsEqual(this.lastPublishedTransforms, next)) return;

    useTransformStore.getState().setPreviewTransformsFromTransformSystem(next);
    this.lastPublishedTransforms = next;
    this.previewListeners.forEach((listener) => listener(next));
  }

  private getSnapDelta(activeNodeIds: NodeId[], delta: TransformDelta): Point {
    if (!isPointDelta(delta) || activeNodeIds.length !== 1) return { x: 0, y: 0 };
    const node = this.sceneGraph.getNode(activeNodeIds[0]);
    if (!node) return { x: 0, y: 0 };
    const initial = this.initialTransforms[node.id] ?? node.transform;
    const movedNode = { ...node, transform: { ...initial, x: initial.x + delta.x, y: initial.y + delta.y } };
    const activeBounds = this.getWorldBounds(movedNode);
    const siblingBounds = this.sceneGraph
      .getChildren(node.parentId ?? node.id)
      .filter((sibling) => sibling.id !== node.id && !sibling.meta.hidden)
      .map((sibling) => this.getWorldBounds(sibling));
    return computeSnap(activeBounds, siblingBounds, this.gridSize, this.snapThreshold).snappedDelta;
  }

  private getWorldBounds(node: SceneNode): Rect {
    return polygonToAABB(getTransformedOBB(node, getWorldTransform(node, this.sceneGraph)));
  }

  private schedulePreviewFlush(): void {
    if (typeof window === "undefined") {
      this.flushPreview();
      return;
    }

    // A single frame gate is the only publication clock. Pointer events may
    // arrive faster than refresh rate; each event replaces pendingTransforms,
    // so renderer, overlay, guides and labels consume the newest absolute
    // transform exactly once before the next paint.
    if (this.frameId !== null) return;
    this.frameId = window.requestAnimationFrame(() => {
      this.frameId = null;
      this.flushPreview();
    });
  }

  private previewMapsEqual(
    previous: Record<NodeId, TransformData> | null,
    next: Record<NodeId, TransformData>,
  ): boolean {
    if (!previous) return false;
    const previousIds = Object.keys(previous);
    const nextIds = Object.keys(next);
    if (previousIds.length !== nextIds.length) return false;
    return nextIds.every((nodeId) => transformsEqual(previous[nodeId], next[nodeId]));
  }

  private clear(): void {
    if (this.frameId !== null && typeof window !== "undefined") {
      window.cancelAnimationFrame(this.frameId);
      this.frameId = null;
    }
    this.pendingTransforms = null;
    this.lastPublishedTransforms = null;
    this.initialTransforms = {};
    interactionElevationSystem.clear();
    useTransformStore.getState().clearTransformFromTransformSystem();
  }
}

export const createTransformSystem = (options?: TransformSystemOptions) => new TransformSystem(options);

export const transformSystem = createTransformSystem();
