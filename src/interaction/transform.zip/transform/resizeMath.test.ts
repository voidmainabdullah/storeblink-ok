import { describe, expect, it } from "vitest";
import type { MoveableEvents } from "react-moveable";
import { DEFAULT_TRANSFORM } from "@/types";
import { getResizeTransformPatch } from "./resizeMath";

describe("resize transform math", () => {
  it("uses zoom-normalized resize distance and ignores unstable absolute translations", () => {
    const transform = { ...DEFAULT_TRANSFORM, x: 120, y: 80, width: 240, height: 160 };
    const event = {
      width: 280,
      height: 190,
      drag: {
        beforeDist: [40, 20],
        beforeTranslate: [32659, 32049],
      },
    } as unknown as MoveableEvents["resize"];

    expect(getResizeTransformPatch({ transform }, event, 2)).toMatchObject({
      x: 140,
      y: 90,
      width: 280,
      height: 190,
    });
  });
});
