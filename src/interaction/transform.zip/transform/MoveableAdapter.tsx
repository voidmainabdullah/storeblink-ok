import { useCallback, useLayoutEffect, useMemo, useState } from "react";
import Moveable, { type MoveableEvents } from "react-moveable";
import { useSceneStore } from "@/stores/scene.store";
import { useSelectionStore } from "@/stores/selection.store";
import { useViewportStore } from "@/stores/viewport.store";
import { useResponsiveStore } from "@/stores/responsive.store";
import type { NodeId, TransformData } from "@/types";
import { transformSystem, type TransformMapDelta } from "./state";
import { responsiveSystem } from "@/layout/responsive";
import { getDocumentDistance, getResizeTransformPatch } from "./resizeMath";

export type MoveableAdapterProps = {
  container: HTMLElement | null;
};

type MoveableTarget = HTMLElement | SVGElement;

const escapeSelectorValue = (value: string): string => value.replace(/\\/g, "\\\\").replace(/"/g, '\\"');

const getTargetNodeId = (target: EventTarget | null | undefined): NodeId | null => {
  if (!(target instanceof Element)) return null;
  return target.getAttribute("data-node-id");
};

const toTransformPatchMap = (
  events: Array<MoveableEvents["resize"] | MoveableEvents["rotate"] | MoveableEvents["scale"]>,
  buildPatch: (event: MoveableEvents["resize"] | MoveableEvents["rotate"] | MoveableEvents["scale"], nodeId: NodeId) => Partial<TransformData>,
): TransformMapDelta => ({
  nodes: Object.fromEntries(
    events
      .map((event) => {
        const nodeId = getTargetNodeId(event.target);
        return nodeId ? [nodeId, buildPatch(event, nodeId)] : null;
      })
      .filter((entry): entry is [NodeId, Partial<TransformData>] => Boolean(entry)),
  ),
});

export const MoveableAdapter = ({ container }: MoveableAdapterProps) => {
  const selectedIds = useSelectionStore((state) => state.selectedIds);
  const editingId = useSelectionStore((state) => state.editingId);
  const sceneRevision = useSceneStore((state) => state.revision);
  const nodes = useSceneStore((state) => state.nodes);
  const zoom = useViewportStore((state) => state.zoom);
  const activeBreakpoint = useResponsiveStore((state) => state.activeBreakpoint);
  const [targets, setTargets] = useState<MoveableTarget[]>([]);
  const interactionNodes = useMemo(
    () =>
      Object.fromEntries(
        selectedIds
          .map((nodeId) => nodes[nodeId])
          .filter(Boolean)
          .map((node) => [
            node.id,
            responsiveSystem.hasOverrides(node)
              ? responsiveSystem.resolveNode(node, activeBreakpoint)
              : node,
          ]),
      ),
    [activeBreakpoint, nodes, selectedIds],
  );

  useLayoutEffect(() => {
    if (!container || !selectedIds.length) {
      setTargets([]);
      return;
    }

    const nextTargets = selectedIds
      .map((nodeId) => container.querySelector(`[data-node-id="${escapeSelectorValue(nodeId)}"]`))
      .filter((target): target is MoveableTarget => target instanceof HTMLElement || target instanceof SVGElement);

    setTargets(nextTargets);
  }, [container, sceneRevision, selectedIds]);

  const beginGesture = useCallback(
    (kind: "move" | "resize" | "rotate" | "scale") => {
      transformSystem.beginTransform(selectedIds, kind);
    },
    [selectedIds],
  );

  const commitGesture = useCallback(() => {
    transformSystem.commitTransform();
  }, []);

  const cancelGesture = useCallback(() => {
    transformSystem.cancelTransform();
  }, []);

  const updateMove = useCallback(
    (event: Pick<MoveableEvents["drag"], "beforeDist" | "dist">) => {
      transformSystem.updateTransform(getDocumentDistance(event.beforeDist ?? event.dist, zoom));
    },
    [zoom],
  );

  const updateResize = useCallback(
    (event: MoveableEvents["resize"]) => {
      const nodeId = getTargetNodeId(event.target);
      transformSystem.updateTransform({
        nodes: nodeId
          ? {
              [nodeId]: getResizeTransformPatch(interactionNodes[nodeId], event, zoom),
            }
          : {},
      });
    },
    [interactionNodes, zoom],
  );

  const updateRotate = useCallback((event: MoveableEvents["rotate"]) => {
    const nodeId = getTargetNodeId(event.target);
    transformSystem.updateTransform({
      nodes: nodeId
        ? {
            [nodeId]: {
              rotation: event.beforeRotation,
            },
          }
        : {},
    });
  }, []);

  const updateScale = useCallback((event: MoveableEvents["scale"]) => {
    const nodeId = getTargetNodeId(event.target);
    transformSystem.updateTransform({
      nodes: nodeId
        ? {
            [nodeId]: {
              scaleX: event.scale[0],
              scaleY: event.scale[1],
            },
          }
        : {},
    });
  }, []);

  const moveableTarget = useMemo(() => {
    if (!targets.length) return null;
    return targets.length === 1 ? targets[0] : targets;
  }, [targets]);

  if (!container || !selectedIds.length || editingId || !moveableTarget) return null;

  return (
    <>
      <Moveable
        target={moveableTarget}
        container={container}
        rootContainer={container}
        className="engine-moveable"
        draggable
        resizable
        rotatable
        scalable
        origin={false}
        throttleDrag={0}
        throttleResize={0}
        throttleRotate={0}
        throttleScale={0}
        zoom={zoom}
        hideDefaultLines={false}
        renderDirections={["nw", "n", "ne", "w", "e", "sw", "s", "se"]}
        keepRatio={false}
        useAccuratePosition
        onDragStart={(event) => {
          event.set([0, 0]);
          beginGesture("move");
        }}
        onDrag={updateMove}
        onDragEnd={(event) => {
          if (event.isDrag) commitGesture();
          else cancelGesture();
        }}
        onDragGroupStart={(event) => {
          event.events.forEach((childEvent) => childEvent.set([0, 0]));
          beginGesture("move");
        }}
        onDragGroup={updateMove}
        onDragGroupEnd={(event) => {
          if (event.isDrag) commitGesture();
          else cancelGesture();
        }}
        onResizeStart={(event) => {
          const nodeId = getTargetNodeId(event.target);
          const transform = nodeId ? interactionNodes[nodeId]?.transform : null;
          if (transform) event.set([transform.width, transform.height]);
          event.dragStart?.set([0, 0]);
          beginGesture("resize");
        }}
        onResize={updateResize}
        onResizeEnd={(event) => {
          if (event.isDrag) commitGesture();
          else cancelGesture();
        }}
        onResizeGroupStart={(event) => {
          event.events.forEach((childEvent) => {
            const nodeId = getTargetNodeId(childEvent.target);
            const transform = nodeId ? interactionNodes[nodeId]?.transform : null;
            if (transform) childEvent.set([transform.width, transform.height]);
            childEvent.dragStart?.set([0, 0]);
          });
          beginGesture("resize");
        }}
        onResizeGroup={(event) => {
          transformSystem.updateTransform(
            toTransformPatchMap(event.events, (childEvent, nodeId) => {
              const resizeEvent = childEvent as MoveableEvents["resize"];
              return getResizeTransformPatch(interactionNodes[nodeId], resizeEvent, zoom);
            }),
          );
        }}
        onResizeGroupEnd={(event) => {
          if (event.isDrag) commitGesture();
          else cancelGesture();
        }}
        onRotateStart={() => beginGesture("rotate")}
        onRotate={updateRotate}
        onRotateEnd={(event) => {
          if (event.isDrag) commitGesture();
          else cancelGesture();
        }}
        onRotateGroupStart={() => beginGesture("rotate")}
        onRotateGroup={(event) => {
          transformSystem.updateTransform(
            toTransformPatchMap(event.events, (childEvent) => ({
              rotation: (childEvent as MoveableEvents["rotate"]).beforeRotation,
            })),
          );
        }}
        onRotateGroupEnd={(event) => {
          if (event.isDrag) commitGesture();
          else cancelGesture();
        }}
        onScaleStart={(event) => {
          const nodeId = getTargetNodeId(event.target);
          const transform = nodeId ? interactionNodes[nodeId]?.transform : null;
          if (transform) event.set([transform.scaleX, transform.scaleY]);
          beginGesture("scale");
        }}
        onScale={updateScale}
        onScaleEnd={(event) => {
          if (event.isDrag) commitGesture();
          else cancelGesture();
        }}
        onScaleGroupStart={(event) => {
          event.events.forEach((childEvent) => {
            const nodeId = getTargetNodeId(childEvent.target);
            const transform = nodeId ? interactionNodes[nodeId]?.transform : null;
            if (transform) childEvent.set([transform.scaleX, transform.scaleY]);
          });
          beginGesture("scale");
        }}
        onScaleGroup={(event) => {
          transformSystem.updateTransform(
            toTransformPatchMap(event.events, (childEvent) => {
              const scaleEvent = childEvent as MoveableEvents["scale"];
              return {
                scaleX: scaleEvent.scale[0],
                scaleY: scaleEvent.scale[1],
              };
            }),
          );
        }}
        onScaleGroupEnd={(event) => {
          if (event.isDrag) commitGesture();
          else cancelGesture();
        }}
      />
      <style>{`
        .engine-moveable .moveable-control-box,
        .engine-moveable .moveable-control,
        .engine-moveable .moveable-line,
        .engine-moveable .moveable-rotation,
        .engine-moveable .moveable-direction {
          pointer-events: auto;
        }
        .engine-moveable .moveable-line {
          background: #0D99FF !important;
        }
        .engine-moveable .moveable-control {
          width: 8px !important;
          height: 8px !important;
          margin-left: -4px !important;
          margin-top: -4px !important;
          border: 1.5px solid #0D99FF !important;
          background: #ffffff !important;
          border-radius: 2px !important;
          box-sizing: border-box !important;
          box-shadow: 0 0 0 1px rgba(255,255,255,0.9);
        }
        .engine-moveable .moveable-rotation-control {
          width: 10px !important;
          height: 10px !important;
          margin-left: -5px !important;
          margin-top: -5px !important;
          border-radius: 999px !important;
        }
      `}</style>
    </>
  );
};

MoveableAdapter.displayName = "MoveableAdapter";
