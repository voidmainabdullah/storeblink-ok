import type { MoveableEvents } from "react-moveable";
import type { TransformData } from "@/types";

export const getDocumentDistance = (distance: number[] | undefined, zoom: number) => ({
  x: (distance?.[0] ?? 0) / Math.max(zoom, 0.001),
  y: (distance?.[1] ?? 0) / Math.max(zoom, 0.001),
});

const finiteNumber = (value: unknown, fallback: number): number =>
  typeof value === "number" && Number.isFinite(value) ? value : fallback;

export const getResizeTransformPatch = (
  node: { transform: TransformData } | undefined,
  event: MoveableEvents["resize"],
  zoom: number,
): Partial<TransformData> => {
  const initial = node?.transform;
  if (!initial) return {};
  const dragDelta = event.drag ? getDocumentDistance(event.drag.beforeDist ?? event.drag.dist, zoom) : { x: 0, y: 0 };
  return {
    x: initial.x + dragDelta.x,
    y: initial.y + dragDelta.y,
    width: Math.max(1, finiteNumber(event.width, initial.width)),
    height: Math.max(1, finiteNumber(event.height, initial.height)),
  };
};
