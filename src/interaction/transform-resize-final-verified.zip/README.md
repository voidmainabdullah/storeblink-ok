# Final Transform Resize Fix

Read `ROOT_CAUSE_REPORT.md` before integration.

## What changed

- Axis-aligned resize now has strict direction invariants.
- Right/bottom resize changes only width/height.
- Left/top resize computes x/y once from the immutable start rectangle.
- Rotated resize still uses Moveable's start-relative `drag.beforeTranslate`.
- `beforeDist` is never used for resize.
- Resize translation is never divided by viewport zoom.
- Width, height, x, and y are published as one atomic preview patch.
- Scene graph/history still commit once at gesture end.
- The dimension badge uses the exact sanitized preview dimensions.

## Verification included

`resizeMath.test.ts` contains direction, drift, zoom, rotation, and invalid-value
regression coverage, including 500-event stress tests.

## Required host-project verification

Run the repository's normal commands after replacing the transform files, for
example:

```bash
npm test
npm run typecheck
npm run build
```

The uploaded archive does not include `package.json` or the imported editor
modules, so complete integration execution is not possible inside this extract.
